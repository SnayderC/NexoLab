# NexoLab

Aplicativo web de gestión de incidencias con clustering de riesgo de equipos (K-Means) para los laboratorios del Bloque H — UNEMI.

**Autores:** Jostyn Snayder Cedeño Jiménez · Joan Martin Rodríguez Cruz

## Stack

| Capa | Tecnología |
|---|---|
| Backend | Python 3.12, Django 5.2 LTS, Django REST Framework |
| Base de datos | PostgreSQL 17 (Docker) |
| Machine Learning | scikit-learn (K-Means) — fase 5 |
| Frontend | React + TypeScript + Vite + Tailwind CSS — fase 6 |

## Estructura

```
nexolab/
├── docker-compose.yml      # PostgreSQL para desarrollo
├── .env.example            # Variables de Docker
└── backend/
    ├── manage.py
    ├── requirements.txt
    ├── .env.example        # Variables de Django
    ├── config/             # settings, urls
    └── apps/
        ├── core/           # BaseModel (is_active, created_at, updated_at) y pruebas de la BD
        ├── users/          # cat_roles, mst_users
        ├── infrastructure/ # mst_laboratories, cat_device_types, cat_device_statuses, mst_devices
        ├── incidents/      # cat_components, cat_incident_statuses, cat_resolution_actions, trx_incidents
        └── risk/           # cat_risk_levels, hst_kmeans_runs, hst_kmeans_centroids, hst_device_risk_results
```

## Instalación (desarrollo)

**Requisitos:** Python 3.12, Docker Desktop y Git.

1. Levantar PostgreSQL:
   ```bash
   cp .env.example .env          # en Windows: copy .env.example .env
   # Edita .env y cambia POSTGRES_PASSWORD
   docker compose up -d
   ```

2. Preparar el backend:
   ```bash
   cd backend
   python -m venv .venv
   # Windows: .venv\Scripts\activate    |   Linux/Mac: source .venv/bin/activate
   pip install -r requirements.txt
   cp .env.example .env
   ```
   Edita `backend/.env`:
   - `SECRET_KEY`: genera una con
     `python -c "import secrets; print(secrets.token_urlsafe(50))"`
   - `DATABASE_URL`: usa la misma contraseña que pusiste en el `.env` de Docker.

3. Crear las tablas y los catálogos:
   ```bash
   python manage.py migrate
   ```

4. Crear el primer administrador:
   ```bash
   python manage.py createsuperuser
   ```

5. Ejecutar:
   ```bash
   python manage.py runserver
   ```
   - API: http://localhost:8000/api/health/
   - Panel de administración: http://localhost:8000/admin/

## Pruebas

```bash
python manage.py test apps
```

## Convenciones

- Tablas y atributos en inglés, `snake_case`, con prefijo por tipo de tabla: `cat_` (catálogo), `mst_` (maestra), `trx_` (transaccional), `hst_` (histórica).
- Todas las tablas tienen `is_active`, `created_at` y `updated_at`. Los registros no se borran: se desactivan.
- Ninguna credencial va en el código: todo se lee de archivos `.env`, que no se suben al repositorio.
