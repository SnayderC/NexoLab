"""Users and roles.

Custom user model: must exist BEFORE the project's first migration.
settings.py -> AUTH_USER_MODEL = "users.User"
"""
from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.db import models

from apps.core.models import BaseModel


class Role(BaseModel):
    TECHNICIAN = "TECHNICIAN"
    ADMIN = "ADMIN"

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=50)

    class Meta:
        db_table = "cat_roles"

    def __str__(self):
        return self.name


class UserManager(BaseUserManager):
    def create_user(self, email, password, role, first_name, last_name, **extra):
        if not email:
            raise ValueError("El email es obligatorio.")
        user = self.model(
            email=self.normalize_email(email),
            role=role,
            first_name=first_name,
            last_name=last_name,
            **extra,
        )
        user.set_password(password)  # stores the hash, never the raw password
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, first_name="Admin", last_name="NexoLab", **extra):
        admin_role = Role.objects.get(code=Role.ADMIN)  # created in a data migration
        return self.create_user(email, password, admin_role, first_name, last_name, **extra)


class User(AbstractBaseUser):
    # Inherited fields renamed to follow the naming convention.
    password = models.CharField(max_length=128, db_column="password_hash")
    last_login = models.DateTimeField(null=True, blank=True, db_column="last_login_at")

    role = models.ForeignKey(Role, on_delete=models.PROTECT, related_name="users")
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=150, unique=True)
    # Record control fields declared here (not via BaseModel) because
    # AbstractBaseUser already defines is_active as a plain attribute.
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    class Meta:
        db_table = "mst_users"

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def is_admin(self):
        return self.role.code == Role.ADMIN

    @property
    def is_staff(self):
        return self.is_active and self.is_admin

    def has_perm(self, perm, obj=None):
        return self.is_staff

    def has_module_perms(self, app_label):
        return self.is_staff
