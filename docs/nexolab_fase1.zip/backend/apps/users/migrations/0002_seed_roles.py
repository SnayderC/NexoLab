from django.db import migrations

ROLES = [
    ("TECHNICIAN", "Técnico de soporte"),
    ("ADMIN", "Administrador"),
]


def seed(apps, schema_editor):
    Role = apps.get_model("users", "Role")
    for code, name in ROLES:
        Role.objects.update_or_create(code=code, defaults={"name": name})


def unseed(apps, schema_editor):
    apps.get_model("users", "Role").objects.filter(code__in=[c for c, _ in ROLES]).delete()


class Migration(migrations.Migration):
    dependencies = [("users", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
