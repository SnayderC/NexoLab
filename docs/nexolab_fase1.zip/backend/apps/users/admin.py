from django.contrib import admin

from .models import Role, User


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_active")


@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("email", "first_name", "last_name", "role", "is_active", "last_login")
    list_filter = ("role", "is_active")
    search_fields = ("email", "first_name", "last_name")
    # The hash is never edited by hand; passwords are set through the API.
    exclude = ("password",)
    readonly_fields = ("last_login", "created_at", "updated_at")
