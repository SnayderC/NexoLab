from django.apps import AppConfig


class RiskConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "apps.risk"
    label = "risk"
    verbose_name = "Riesgo (K-Means)"
