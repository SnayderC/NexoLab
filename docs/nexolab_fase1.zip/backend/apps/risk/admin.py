from django.contrib import admin

from .models import DeviceRiskResult, KMeansCentroid, KMeansRun, RiskLevel

admin.site.register([RiskLevel, KMeansCentroid])


@admin.register(KMeansRun)
class KMeansRunAdmin(admin.ModelAdmin):
    list_display = ("id", "trigger_type", "run_status", "device_count", "silhouette_score", "started_at")


@admin.register(DeviceRiskResult)
class DeviceRiskResultAdmin(admin.ModelAdmin):
    list_display = ("device", "risk_level", "classification_method", "is_current", "calculated_at")
    list_filter = ("risk_level", "classification_method", "is_current")
