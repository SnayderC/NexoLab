from django.db import migrations

RISK_LEVELS = [
    # code, name, recommended_action, color_hex
    ("HIGH", "Riesgo alto", "Revisar hoy", "#EF4444"),
    ("MEDIUM", "Riesgo medio", "Programar revisión esta semana", "#F59E0B"),
    ("LOW", "Riesgo bajo", "Monitoreo normal", "#10B981"),
]


def seed(apps, schema_editor):
    RiskLevel = apps.get_model("risk", "RiskLevel")
    for code, name, action, color in RISK_LEVELS:
        RiskLevel.objects.update_or_create(
            code=code,
            defaults={"name": name, "recommended_action": action, "color_hex": color},
        )


def unseed(apps, schema_editor):
    apps.get_model("risk", "RiskLevel").objects.filter(
        code__in=[c for c, _, _, _ in RISK_LEVELS]
    ).delete()


class Migration(migrations.Migration):
    dependencies = [("risk", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
