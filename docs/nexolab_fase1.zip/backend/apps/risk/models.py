"""K-Means: risk levels catalog and historical tables (runs, centroids, results)."""
from django.conf import settings
from django.db import models
from django.db.models import Q

from apps.core.models import BaseModel


class RiskLevel(BaseModel):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"

    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=50)
    recommended_action = models.CharField(max_length=150, blank=True)
    color_hex = models.CharField(max_length=7, blank=True)  # #EF4444, #F59E0B, #10B981

    class Meta:
        db_table = "cat_risk_levels"

    def __str__(self):
        return self.name


class KMeansRun(BaseModel):
    class TriggerType(models.TextChoices):
        INITIAL_LOAD = "INITIAL_LOAD", "Carga inicial"
        INCIDENT_CLOSED = "INCIDENT_CLOSED", "Cierre de incidencia"
        CATALOG_CHANGE = "CATALOG_CHANGE", "Cambio de catálogo"
        MANUAL = "MANUAL", "Manual"

    class RunStatus(models.TextChoices):
        RUNNING = "RUNNING", "En curso"
        COMPLETED = "COMPLETED", "Completada"
        FAILED = "FAILED", "Error"

    id = models.BigAutoField(primary_key=True)
    trigger_type = models.CharField(max_length=30, choices=TriggerType.choices)
    triggered_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kmeans_runs",
    )
    incident = models.ForeignKey(
        "incidents.Incident",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="kmeans_runs",
    )
    run_status = models.CharField(max_length=15, choices=RunStatus.choices)
    cluster_count = models.PositiveSmallIntegerField(default=3)  # k
    max_iterations = models.PositiveIntegerField(default=100)
    iteration_count = models.PositiveIntegerField(null=True, blank=True)
    has_converged = models.BooleanField(null=True, blank=True)
    random_seed = models.IntegerField()  # reproducibility
    device_count = models.PositiveIntegerField(null=True, blank=True)
    inertia = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    silhouette_score = models.DecimalField(max_digits=6, decimal_places=5, null=True, blank=True)
    davies_bouldin_index = models.DecimalField(max_digits=10, decimal_places=5, null=True, blank=True)
    parameters = models.JSONField(null=True, blank=True)  # jsonb in PostgreSQL
    error_message = models.TextField(blank=True)
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField(null=True, blank=True)
    duration_ms = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        db_table = "hst_kmeans_runs"
        ordering = ["-started_at"]


class KMeansCentroid(BaseModel):
    id = models.BigAutoField(primary_key=True)
    kmeans_run = models.ForeignKey(KMeansRun, on_delete=models.CASCADE, related_name="centroids")
    cluster_index = models.PositiveSmallIntegerField()
    risk_level = models.ForeignKey(RiskLevel, on_delete=models.PROTECT)
    avg_incident_count = models.DecimalField(max_digits=10, decimal_places=4)
    avg_days_since_last_failure = models.DecimalField(max_digits=10, decimal_places=4)
    avg_failure_interval_days = models.DecimalField(max_digits=10, decimal_places=4)
    device_count = models.PositiveIntegerField()

    class Meta:
        db_table = "hst_kmeans_centroids"
        constraints = [
            models.UniqueConstraint(
                fields=["kmeans_run", "cluster_index"], name="uq_hst_kmeans_centroids_run_cluster"
            ),
        ]


class DeviceRiskResult(BaseModel):
    class Method(models.TextChoices):
        KMEANS = "KMEANS", "K-Means"
        # Agreed rule: devices with fewer than 2 incidents -> LOW risk
        INSUFFICIENT_HISTORY = "INSUFFICIENT_HISTORY", "Sin historial suficiente"

    id = models.BigAutoField(primary_key=True)
    kmeans_run = models.ForeignKey(KMeansRun, on_delete=models.CASCADE, related_name="results")
    device = models.ForeignKey(
        "infrastructure.Device", on_delete=models.PROTECT, related_name="risk_results"
    )
    classification_method = models.CharField(max_length=25, choices=Method.choices)
    kmeans_centroid = models.ForeignKey(
        KMeansCentroid, on_delete=models.CASCADE, null=True, blank=True, related_name="results"
    )
    risk_level = models.ForeignKey(RiskLevel, on_delete=models.PROTECT)
    incident_count = models.PositiveIntegerField()
    days_since_last_failure = models.PositiveIntegerField(null=True, blank=True)
    avg_failure_interval_days = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    distance_to_centroid = models.DecimalField(max_digits=12, decimal_places=6, null=True, blank=True)
    is_current = models.BooleanField(default=False)
    calculated_at = models.DateTimeField()

    class Meta:
        db_table = "hst_device_risk_results"
        constraints = [
            models.UniqueConstraint(
                fields=["device"],
                condition=Q(is_current=True),
                name="uq_hst_device_risk_results_current",
            ),
            models.CheckConstraint(
                condition=(
                    Q(classification_method="KMEANS", kmeans_centroid__isnull=False)
                    | Q(classification_method="INSUFFICIENT_HISTORY", kmeans_centroid__isnull=True)
                ),
                name="ck_hst_device_risk_results_method_centroid",
            ),
        ]
