"""Shared abstract base model with record control fields."""
from django.db import models


class BaseModel(models.Model):
    """Record control fields required in every table.

    is_active is the RECORD status (logical delete), not the business status:
    a retired device or a closed incident is still an active record.
    """

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
