"""Tests for the database layer: catalogs, record control fields and integrity rules."""
from datetime import timedelta

from django.db import IntegrityError, transaction
from django.db.models import ProtectedError
from django.test import TestCase
from django.utils import timezone

from apps.incidents.models import Component, Incident, IncidentStatus, ResolutionAction
from apps.infrastructure.models import Device, DeviceStatus, DeviceType, Laboratory
from apps.risk.models import DeviceRiskResult, KMeansCentroid, KMeansRun, RiskLevel
from apps.users.models import Role, User


def make_base_data():
    """Minimal valid data: one technician, one lab and one device."""
    tech = User.objects.create_user(
        "carlos.mendoza@gmail.com", "Clave-Segura-2026",
        Role.objects.get(code=Role.TECHNICIAN), "Carlos", "Mendoza",
    )
    lab = Laboratory.objects.create(code="H103", name="Laboratorio de Redes", station_count=12)
    device = Device.objects.create(
        code="H103-PC-03",
        laboratory=lab,
        device_type=DeviceType.objects.get(code="PC"),
        device_status=DeviceStatus.objects.get(code=DeviceStatus.ACTIVE),
    )
    return tech, lab, device


def make_incident(device, user, number="INC-2026-0001", **extra):
    return Incident.objects.create(
        incident_number=number,
        device=device,
        component=Component.objects.get(code="MOUSE"),
        incident_status=IncidentStatus.objects.get(code=IncidentStatus.OPEN),
        reported_by=user,
        priority=Incident.Priority.MEDIUM,
        description="El mouse no responde al moverlo.",
        opened_at=timezone.now(),
        **extra,
    )


class CatalogSeedTests(TestCase):
    def test_catalogs_are_loaded_by_migrations(self):
        self.assertEqual(Role.objects.count(), 2)
        self.assertEqual(DeviceType.objects.count(), 32)
        self.assertEqual(DeviceStatus.objects.count(), 2)
        self.assertEqual(Component.objects.count(), 5)
        self.assertEqual(IncidentStatus.objects.count(), 2)
        self.assertEqual(ResolutionAction.objects.count(), 3)
        self.assertEqual(RiskLevel.objects.count(), 3)

    def test_no_device_type_is_selected_by_default(self):
        # Selection belongs to each institution, not to the generic catalog.
        self.assertFalse(DeviceType.objects.filter(is_selected=True).exists())

    def test_only_replacement_retires_the_device(self):
        retiring = ResolutionAction.objects.filter(is_retirement_action=True)
        self.assertEqual(list(retiring.values_list("code", flat=True)), ["REPLACEMENT_REQUIRED"])

    def test_retired_devices_are_excluded_from_kmeans(self):
        self.assertFalse(DeviceStatus.objects.get(code="RETIRED").is_included_in_kmeans)


class RecordControlTests(TestCase):
    def test_new_records_are_active_and_timestamped(self):
        _, lab, _ = make_base_data()
        self.assertTrue(lab.is_active)
        self.assertIsNotNone(lab.created_at)
        self.assertIsNotNone(lab.updated_at)


class UserTests(TestCase):
    def test_password_is_stored_as_hash(self):
        tech, _, _ = make_base_data()
        self.assertNotEqual(tech.password, "Clave-Segura-2026")
        self.assertTrue(tech.check_password("Clave-Segura-2026"))

    def test_email_must_be_unique(self):
        make_base_data()
        with self.assertRaises(IntegrityError):
            User.objects.create_user(
                "carlos.mendoza@gmail.com", "Otra-Clave-2026",
                Role.objects.get(code=Role.TECHNICIAN), "Otro", "Usuario",
            )


class IncidentIntegrityTests(TestCase):
    def setUp(self):
        self.tech, self.lab, self.device = make_base_data()

    def test_closed_at_cannot_be_before_opened_at(self):
        with self.assertRaises(IntegrityError):
            make_incident(self.device, self.tech, closed_at=timezone.now() - timedelta(days=1))

    def test_invalid_priority_is_rejected_by_the_database(self):
        incident = make_incident(self.device, self.tech)
        incident.priority = "URGENT"
        with self.assertRaises(IntegrityError):
            incident.save()

    def test_device_with_incidents_cannot_be_deleted(self):
        make_incident(self.device, self.tech)
        with self.assertRaises(ProtectedError):
            self.device.delete()


class RiskIntegrityTests(TestCase):
    def setUp(self):
        _, _, self.device = make_base_data()
        self.run = KMeansRun.objects.create(
            trigger_type=KMeansRun.TriggerType.MANUAL,
            run_status=KMeansRun.RunStatus.COMPLETED,
            random_seed=42,
            started_at=timezone.now(),
        )
        self.high = RiskLevel.objects.get(code=RiskLevel.HIGH)
        self.low = RiskLevel.objects.get(code=RiskLevel.LOW)
        self.centroid = KMeansCentroid.objects.create(
            kmeans_run=self.run, cluster_index=0, risk_level=self.high,
            avg_incident_count=8.8, avg_days_since_last_failure=3,
            avg_failure_interval_days=6, device_count=6,
        )

    def _result(self, **kwargs):
        defaults = dict(
            kmeans_run=self.run, device=self.device, incident_count=11,
            calculated_at=timezone.now(),
        )
        defaults.update(kwargs)
        return DeviceRiskResult.objects.create(**defaults)

    def test_only_one_current_result_per_device(self):
        self._result(classification_method="KMEANS", kmeans_centroid=self.centroid,
                     risk_level=self.high, is_current=True)
        with self.assertRaises(IntegrityError):
            self._result(classification_method="KMEANS", kmeans_centroid=self.centroid,
                         risk_level=self.high, is_current=True)

    def test_kmeans_result_requires_a_centroid(self):
        with self.assertRaises(IntegrityError):
            self._result(classification_method="KMEANS", risk_level=self.high)

    def test_insufficient_history_result_cannot_have_a_centroid(self):
        with self.assertRaises(IntegrityError), transaction.atomic():
            self._result(classification_method="INSUFFICIENT_HISTORY",
                         kmeans_centroid=self.centroid, risk_level=self.low, incident_count=1)
        # Without centroid it is valid.
        self._result(classification_method="INSUFFICIENT_HISTORY",
                     risk_level=self.low, incident_count=1)

    def test_cluster_index_is_unique_per_run(self):
        with self.assertRaises(IntegrityError):
            KMeansCentroid.objects.create(
                kmeans_run=self.run, cluster_index=0, risk_level=self.low,
                avg_incident_count=2, avg_days_since_last_failure=60,
                avg_failure_interval_days=70, device_count=21,
            )
