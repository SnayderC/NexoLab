from django.apps import AppConfig


class IncidentsConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "apps.incidents"
    label = "incidents"
    verbose_name = "Incidencias"
