from django.contrib import admin

from .models import Component, Incident, IncidentStatus, ResolutionAction

admin.site.register([Component, IncidentStatus, ResolutionAction])


@admin.register(Incident)
class IncidentAdmin(admin.ModelAdmin):
    list_display = ("incident_number", "device", "component", "priority", "incident_status", "opened_at", "is_active")
    list_filter = ("incident_status", "priority", "is_active")
    search_fields = ("incident_number", "device__code")
