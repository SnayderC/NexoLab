"""Incidents and their catalogs."""
from django.conf import settings
from django.core.validators import MaxLengthValidator, MinLengthValidator
from django.db import models
from django.db.models import F, Q

from apps.core.models import BaseModel


class Component(BaseModel):
    """Affected component: PC, Monitor, Keyboard, Mouse, UPS..."""

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=80)

    class Meta:
        db_table = "cat_components"
        ordering = ["name"]

    def __str__(self):
        return self.name


class IncidentStatus(BaseModel):
    OPEN = "OPEN"
    CLOSED = "CLOSED"

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=50)
    is_final = models.BooleanField()

    class Meta:
        db_table = "cat_incident_statuses"
        verbose_name_plural = "incident statuses"

    def __str__(self):
        return self.name


class ResolutionAction(BaseModel):
    """Case study: resolved, replacement required, referred."""

    RESOLVED = "RESOLVED"
    REPLACEMENT_REQUIRED = "REPLACEMENT_REQUIRED"
    REFERRED = "REFERRED"

    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=100)
    is_retirement_action = models.BooleanField(default=False)  # True -> device becomes RETIRED

    class Meta:
        db_table = "cat_resolution_actions"

    def __str__(self):
        return self.name


class Incident(BaseModel):
    class Priority(models.TextChoices):
        HIGH = "HIGH", "Alta"
        MEDIUM = "MEDIUM", "Media"
        LOW = "LOW", "Baja"

    id = models.BigAutoField(primary_key=True)
    incident_number = models.CharField(max_length=20, unique=True)  # INC-2026-0001
    device = models.ForeignKey(
        "infrastructure.Device", on_delete=models.PROTECT, related_name="incidents"
    )
    component = models.ForeignKey(Component, on_delete=models.PROTECT, related_name="incidents")
    # Business status (open/closed). Record status is BaseModel.is_active.
    incident_status = models.ForeignKey(
        IncidentStatus, on_delete=models.PROTECT, related_name="incidents"
    )
    resolution_action = models.ForeignKey(
        ResolutionAction, on_delete=models.PROTECT, null=True, blank=True, related_name="incidents"
    )
    reported_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="reported_incidents"
    )
    closed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="closed_incidents",
    )
    priority = models.CharField(max_length=10, choices=Priority.choices)
    description = models.TextField(validators=[MinLengthValidator(10), MaxLengthValidator(500)])
    diagnosis = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    opened_at = models.DateTimeField()  # when the failure happened
    closed_at = models.DateTimeField(null=True, blank=True)
    resolution_time_minutes = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        db_table = "trx_incidents"
        ordering = ["-opened_at"]
        indexes = [
            models.Index(fields=["device", "opened_at"], name="idx_trx_inc_device_opened"),
        ]
        constraints = [
            models.CheckConstraint(
                condition=Q(closed_at__isnull=True) | Q(closed_at__gte=F("opened_at")),
                name="ck_trx_incidents_closed_after_opened",
            ),
            models.CheckConstraint(
                condition=Q(priority__in=["HIGH", "MEDIUM", "LOW"]),
                name="ck_trx_incidents_valid_priority",
            ),
        ]

    def __str__(self):
        return self.incident_number
