from django.db import migrations

COMPONENTS = [
    ("PC", "PC"),
    ("MONITOR", "Monitor"),
    ("KEYBOARD", "Teclado"),
    ("MOUSE", "Mouse"),
    ("UPS", "UPS"),
]

INCIDENT_STATUSES = [
    # code, name, is_final
    ("OPEN", "Abierta", False),
    ("CLOSED", "Cerrada", True),
]

RESOLUTION_ACTIONS = [
    # code, name, is_retirement_action
    ("RESOLVED", "Resuelto", False),
    ("REPLACEMENT_REQUIRED", "Requiere reemplazo", True),
    ("REFERRED", "Derivado", False),
]


def seed(apps, schema_editor):
    Component = apps.get_model("incidents", "Component")
    IncidentStatus = apps.get_model("incidents", "IncidentStatus")
    ResolutionAction = apps.get_model("incidents", "ResolutionAction")
    for code, name in COMPONENTS:
        Component.objects.update_or_create(code=code, defaults={"name": name})
    for code, name, is_final in INCIDENT_STATUSES:
        IncidentStatus.objects.update_or_create(
            code=code, defaults={"name": name, "is_final": is_final}
        )
    for code, name, retires in RESOLUTION_ACTIONS:
        ResolutionAction.objects.update_or_create(
            code=code, defaults={"name": name, "is_retirement_action": retires}
        )


def unseed(apps, schema_editor):
    apps.get_model("incidents", "Component").objects.filter(
        code__in=[c for c, _ in COMPONENTS]
    ).delete()
    apps.get_model("incidents", "IncidentStatus").objects.filter(
        code__in=[c for c, _, _ in INCIDENT_STATUSES]
    ).delete()
    apps.get_model("incidents", "ResolutionAction").objects.filter(
        code__in=[c for c, _, _ in RESOLUTION_ACTIONS]
    ).delete()


class Migration(migrations.Migration):
    dependencies = [("incidents", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
