"""Laboratories, device catalogs and devices."""
from django.conf import settings
from django.db import models

from apps.core.models import BaseModel


class Laboratory(BaseModel):
    code = models.CharField(max_length=10, unique=True)  # H101
    name = models.CharField(max_length=100)
    location = models.CharField(max_length=150, blank=True)  # free text
    station_count = models.PositiveSmallIntegerField()  # workstations, not devices
    responsible_technician = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="responsible_laboratories",
    )

    class Meta:
        db_table = "mst_laboratories"
        ordering = ["code"]
        verbose_name_plural = "laboratories"

    def __str__(self):
        return self.code


class DeviceType(BaseModel):
    """Extensible catalog. is_selected = chosen in the catalog configuration screen."""

    code = models.CharField(max_length=10, unique=True)  # PC, MON, AIO, UPS, TV
    name = models.CharField(max_length=80)
    is_selected = models.BooleanField(default=False)

    class Meta:
        db_table = "cat_device_types"
        ordering = ["name"]

    def __str__(self):
        return self.name


class DeviceStatus(BaseModel):
    ACTIVE = "ACTIVE"
    RETIRED = "RETIRED"

    code = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=50)
    is_included_in_kmeans = models.BooleanField()

    class Meta:
        db_table = "cat_device_statuses"
        verbose_name_plural = "device statuses"

    def __str__(self):
        return self.name


class Device(BaseModel):
    code = models.CharField(max_length=30, unique=True)  # H103-PC-03
    laboratory = models.ForeignKey(Laboratory, on_delete=models.PROTECT, related_name="devices")
    device_type = models.ForeignKey(DeviceType, on_delete=models.PROTECT, related_name="devices")
    # Business status (active/retired). Record status is BaseModel.is_active.
    device_status = models.ForeignKey(DeviceStatus, on_delete=models.PROTECT, related_name="devices")
    physical_location = models.CharField(max_length=100, blank=True)  # "Fila 2, puesto 5"
    specifications = models.TextField(blank=True)
    retired_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "mst_devices"
        ordering = ["code"]

    def __str__(self):
        return self.code
