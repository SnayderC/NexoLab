from django.apps import AppConfig


class InfrastructureConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "apps.infrastructure"
    label = "infrastructure"
    verbose_name = "Infraestructura"
