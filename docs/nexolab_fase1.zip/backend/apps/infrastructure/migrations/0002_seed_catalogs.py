from django.db import migrations

DEVICE_STATUSES = [
    # code, name, is_included_in_kmeans
    ("ACTIVE", "Activo", True),
    ("RETIRED", "Retirado", False),
]

# Generic catalog universe. No type is selected here: the selection belongs to
# each institution and is made in the "Catálogo de equipos" screen (or by the
# Bloque H seed command).
DEVICE_TYPES = [
    ("PC", "PC de escritorio"),
    ("MON", "Monitor"),
    ("AIO", "Todo en uno"),
    ("UPS", "UPS"),
    ("TV", "Televisor"),
    ("LAP", "Laptop"),
    ("PROY", "Proyector"),
    ("IMP", "Impresora"),
    ("MFP", "Impresora multifunción"),
    ("ESC", "Escáner"),
    ("SW", "Switch"),
    ("RTR", "Router"),
    ("AP", "Punto de acceso inalámbrico"),
    ("SRV", "Servidor"),
    ("TAB", "Tablet"),
    ("PIZ", "Pizarra digital"),
    ("CAM", "Cámara web"),
    ("PAR", "Parlantes"),
    ("MIC", "Micrófono"),
    ("HDD", "Disco duro externo"),
    ("NAS", "Almacenamiento en red (NAS)"),
    ("FW", "Firewall"),
    ("TIP", "Teléfono IP"),
    ("PLT", "Plotter"),
    ("LCB", "Lector de código de barras"),
    ("KIO", "Kiosco interactivo"),
    ("RCK", "Rack de comunicaciones"),
    ("CIP", "Cámara IP"),
    ("VCF", "Equipo de videoconferencia"),
    ("CAU", "Consola de audio"),
    ("CDOC", "Cámara de documentos"),
    ("BIO", "Lector biométrico"),
]


def seed(apps, schema_editor):
    DeviceStatus = apps.get_model("infrastructure", "DeviceStatus")
    DeviceType = apps.get_model("infrastructure", "DeviceType")
    for code, name, included in DEVICE_STATUSES:
        DeviceStatus.objects.update_or_create(
            code=code, defaults={"name": name, "is_included_in_kmeans": included}
        )
    for code, name in DEVICE_TYPES:
        DeviceType.objects.update_or_create(code=code, defaults={"name": name})


def unseed(apps, schema_editor):
    apps.get_model("infrastructure", "DeviceStatus").objects.filter(
        code__in=[c for c, _, _ in DEVICE_STATUSES]
    ).delete()
    apps.get_model("infrastructure", "DeviceType").objects.filter(
        code__in=[c for c, _ in DEVICE_TYPES]
    ).delete()


class Migration(migrations.Migration):
    dependencies = [("infrastructure", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
