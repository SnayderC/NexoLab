from django.contrib import admin

from .models import Device, DeviceStatus, DeviceType, Laboratory


@admin.register(Laboratory)
class LaboratoryAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "location", "station_count", "responsible_technician", "is_active")


@admin.register(DeviceType)
class DeviceTypeAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_selected", "is_active")
    list_filter = ("is_selected",)


@admin.register(DeviceStatus)
class DeviceStatusAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_included_in_kmeans", "is_active")


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ("code", "device_type", "laboratory", "device_status", "is_active")
    list_filter = ("laboratory", "device_type", "device_status", "is_active")
    search_fields = ("code",)
